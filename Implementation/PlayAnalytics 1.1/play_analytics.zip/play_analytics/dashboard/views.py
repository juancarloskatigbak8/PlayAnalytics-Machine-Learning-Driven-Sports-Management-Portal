from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from django.db.models import Avg
from profiles.models import Player
import pandas as pd

@login_required
def dashboard_view(request):
    players = Player.objects.all()
    total_players = players.count()

    avg_age = round(players.aggregate(Avg('age'))['age__avg'], 1) if total_players else 0
    avg_injuries = round(players.aggregate(Avg('total_injuries'))['total_injuries__avg'], 1) if total_players else 0
    avg_height = round(players.aggregate(Avg('height'))['height__avg'], 1) if total_players else 0
    avg_weight = round(players.aggregate(Avg('weight'))['weight__avg'], 1) if total_players else 0

    pie_labels = ['Ankle', 'Knee', 'Back', 'Quad', 'Hamstring']
    pie_values = [24, 18, 12, 9, 7]

    df = pd.DataFrame(list(players.values('position', 'total_injuries')))
    bar_data = df.groupby('position')['total_injuries'].mean().sort_values(ascending=False)
    bar_labels = list(bar_data.index)
    bar_values = list(bar_data.values)

    context = {
        'total_players': total_players,
        'avg_age': avg_age,
        'avg_height': avg_height,
        'avg_weight': avg_weight,
        'avg_injuries': avg_injuries,
        'pie_labels': pie_labels,
        'pie_values': pie_values,
        'bar_labels': bar_labels,
        'bar_values': bar_values,
    }

    return render(request, 'dashboard/dashboard.html', context)
