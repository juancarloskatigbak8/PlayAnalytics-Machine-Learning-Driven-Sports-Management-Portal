from django.urls import path
from . import views

app_name = 'predictor'  # This allows using {% url 'predictor:predict_injury' %}

urlpatterns = [
    path('', views.predict_injury, name='predict_injury'),
    path('add/', views.add_to_profile, name='add_to_profile'),
]
