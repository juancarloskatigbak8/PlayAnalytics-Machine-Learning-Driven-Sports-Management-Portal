from django.urls import path
from . import views

app_name = 'player_profiles'

urlpatterns = [
    path('', views.index, name='index'),
    path('profiles/', views.profile_list, name='profile_list'),
    path('profiles/add/', views.add_player, name='add_player'),
    path('profiles/<int:pk>/', views.profile_detail, name='profile_detail'),
    path('profiles/<int:pk>/add_note/', views.add_note, name='add_note'),
    path('profiles/<int:pk>/delete/', views.delete_player, name='delete_player'),
    path('notes/<int:note_id>/delete/', views.delete_note, name='delete_note'),
    path('notes/<int:note_id>/edit/', views.edit_note, name='edit_note'),
]
