from django import forms
from .models import PlayerProfile, PlayerNotes

class PlayerProfileForm(forms.ModelForm):
    class Meta:
        model = PlayerProfile
        fields = '__all__'

class PlayerNoteForm(forms.ModelForm):
    class Meta:
        model = PlayerNotes
        fields = ['text']

class NoteForm(forms.ModelForm):
    class Meta:
        model = PlayerNotes
        fields = ['text']

