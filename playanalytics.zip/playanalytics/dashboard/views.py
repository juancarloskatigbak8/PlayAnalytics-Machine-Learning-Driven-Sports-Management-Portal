from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from django.db.models import Avg, Count
from player_profiles.models import PlayerProfile
from collections import defaultdict

# === Public Landing Page View ===
def landing_page(request):
    # This renders the homepage (index.html) for all visitors (no login required).
    return render(request, 'index.html')

# === Protected Dashboard View ===
@login_required
def dashboard_view(request):
    """
    Generates statistics and charts for the logged-in user's dashboard.
    Displays injury data summaries, risk levels, and injury distributions.
    """

    # --- 1. Average Total Injuries by Position (for bar chart) ---
    avg_injuries = PlayerProfile.objects.values('position').annotate(avg=Avg('total_injuries'))
    injuries_by_position = {
        entry['position']: round(entry['avg'], 2) for entry in avg_injuries
    }

    # --- 2. Injury Type Distribution (for pie chart) ---
    injury_counts = PlayerProfile.objects.values('most_common_injury').annotate(count=Count('most_common_injury'))
    total_injuries = sum(entry['count'] for entry in injury_counts)
    injuries_by_type = {
        entry['most_common_injury']: round((entry['count'] / total_injuries) * 100, 2)
        for entry in injury_counts if entry['most_common_injury']
    }

    # --- 3. Risk Level Distribution per Position (stacked bar chart) ---
    risk_levels = ["High", "Medium-High", "Medium", "Low-Medium", "Low"]
    risk_raw = defaultdict(lambda: {level: 0 for level in risk_levels})

    for player in PlayerProfile.objects.all():
        risk = player.predicted_risk_label
        pos = player.position
        if risk in risk_levels:
            risk_raw[pos][risk] += 1

    positions = list(risk_raw.keys())
    risk_datasets = [
        {
            'label': level,
            'data': [risk_raw[pos][level] for pos in positions],
            'stack': 'Stack'
        }
        for level in risk_levels
    ]

    # --- 4. Compute Summary Indicators ---
    num_players = PlayerProfile.objects.count()
    avg_age = round(PlayerProfile.objects.aggregate(avg=Avg("age"))["avg"] or 0, 1)
    avg_injuries_total = round(PlayerProfile.objects.aggregate(avg=Avg("total_injuries"))["avg"] or 0, 2)
    common_injury_entry = (
        PlayerProfile.objects.values("most_common_injury")
        .annotate(count=Count("most_common_injury"))
        .order_by("-count")
        .first()
    )
    common_injury = common_injury_entry.get("most_common_injury", "None") if common_injury_entry else "None"

    # --- 5. Send all data to the template ---
    context = {
        'injuries_by_position': injuries_by_position,
        'injuries_by_position_labels': list(injuries_by_position.keys()),
        'injuries_by_position_values': list(injuries_by_position.values()),
        'injury_type_labels': list(injuries_by_type.keys()),
        'injury_type_values': list(injuries_by_type.values()),
        'positions': positions,
        'risk_datasets': risk_datasets,
        'num_players': num_players,
        'avg_age': avg_age,
        'avg_injuries': avg_injuries_total,
        'common_injury': common_injury,
    }

    return render(request, "dashboard/dashboard.html", context)
