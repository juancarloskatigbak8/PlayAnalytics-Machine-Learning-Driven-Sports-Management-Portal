from django.db import models
from django.contrib.auth.models import User

# Create your models here.

class Player(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, null=True)
    player_name = models.CharField(max_length=100)
    position = models.CharField(max_length=50)
    height = models.FloatField()
    weight = models.FloatField()
    age = models.IntegerField()
    games_played = models.IntegerField(default=0)
    avg_minutes = models.FloatField()
    avg_field_goals = models.FloatField()
    steals_per_game = models.FloatField()
    blocks_per_game = models.FloatField()
    fouls_per_game = models.FloatField()
    total_injuries = models.IntegerField()
    most_common_injury = models.CharField(max_length=100)
    cumulative_load = models.FloatField(default=0.0)
    risk_level = models.CharField(max_length=50)

    def __str__(self):
        return self.player_name


class JournalEntry(models.Model):
    player = models.ForeignKey(Player, on_delete=models.CASCADE, related_name='journal_entries')
    date = models.DateField()
    title = models.CharField(max_length=200)
    note = models.TextField()