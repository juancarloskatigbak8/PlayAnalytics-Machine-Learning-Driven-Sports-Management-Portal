from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth.decorators import login_required
from django.db.models import Avg
from .models import Player
from .forms import PlayerForm, JournalEntryForm

@login_required
def player_list(request):
    players = Player.objects.all()
    return render(request, 'profiles/player_list.html', {'players': players})

@login_required
def player_detail(request, player_id):
    player = get_object_or_404(Player, id=player_id)
    entries = player.journal_entries.all()
    return render(request, 'profiles/player_detail.html', {'player': player, 'entries': entries})

@login_required
def edit_player(request, player_id):
    player = get_object_or_404(Player, id=player_id)
    form = PlayerForm(request.POST or None, request.FILES or None, instance=player)
    if form.is_valid():
        form.save()
        return redirect('profiles:player_detail', player.id)
    return render(request, 'profiles/edit_player.html', {'form': form, 'player': player})

@login_required
def add_journal_entry(request, player_id):
    player = get_object_or_404(Player, id=player_id)
    form = JournalEntryForm(request.POST or None)
    if form.is_valid():
        entry = form.save(commit=False)
        entry.player = player
        entry.save()
        return redirect('profiles:player_detail', player.id)
    return render(request, 'profiles/journal_entry.html', {'form': form, 'player': player})

@login_required
def profile_view(request):
    players = Player.objects.filter(user=request.user)
    average_injuries = players.aggregate(Avg('total_injuries'))['total_injuries__avg']
    context = {
        'players': players,
        'average_injuries': round(average_injuries or 0, 2),
        'player_count': players.count()
    }
    return render(request, 'profiles/profile.html', context)

