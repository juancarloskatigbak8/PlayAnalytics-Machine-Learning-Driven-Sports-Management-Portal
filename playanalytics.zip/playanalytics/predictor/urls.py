from django.urls import path
from . import views

app_name = 'predictor'

urlpatterns = [
    path('predict/', views.predict_injury, name='predict_injury'),
    path('add-to-profile/', views.add_to_profile, name='add_to_profile'), 
]
