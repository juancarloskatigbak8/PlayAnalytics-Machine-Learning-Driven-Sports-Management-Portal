from django.shortcuts import render
from player_profiles.models import PlayerProfile
from collections import defaultdict
from django.db.models import Avg, Count

def dashboard_view(request):
    # Avg injuries by position
    avg_injuries = PlayerProfile.objects.values('position').annotate(avg=Avg('total_injuries'))
    injuries_by_position = {entry['position']: round(entry['avg'], 2) for entry in avg_injuries}

    # Injury type percentages
    injury_counts = PlayerProfile.objects.values('most_common_injury').annotate(count=Count('most_common_injury'))
    total_injuries = sum(entry['count'] for entry in injury_counts)
    injuries_by_type = {
        entry['most_common_injury']: round((entry['count'] / total_injuries) * 100, 2)
        for entry in injury_counts if entry['most_common_injury']
    }

    # Risk levels (in preferred order)
    risk_levels = ["High", "Medium-High", "Medium", "Low-Medium", "Low"]

    # Risk level distribution per position
    risk_raw = defaultdict(lambda: {level: 0 for level in risk_levels})
    for player in PlayerProfile.objects.all():
        risk = player.predicted_risk_label
        pos = player.position
        if risk in risk_levels:
            risk_raw[pos][risk] += 1

    positions = list(risk_raw.keys())
    risk_datasets = []
    for level in risk_levels:
        risk_datasets.append({
            'label': level,
            'data': [risk_raw[pos][level] for pos in positions],
            'stack': 'Stack'
        })

    context = {
        'injuries_by_position': injuries_by_position,
        'injury_type_labels': list(injuries_by_type.keys()),
        'injury_type_values': list(injuries_by_type.values()),
        'positions': positions,
        'risk_datasets': risk_datasets,
        'num_players': PlayerProfile.objects.count(),
        'avg_age': round(PlayerProfile.objects.aggregate(avg=Avg("age"))["avg"] or 0, 1),
        'avg_injuries': round(PlayerProfile.objects.aggregate(avg=Avg("total_injuries"))["avg"] or 0, 2),
        'common_injury': PlayerProfile.objects.values("most_common_injury")
                            .annotate(count=Count("most_common_injury"))
                            .order_by("-count")
                            .first().get("most_common_injury", "None") if PlayerProfile.objects.exists() else "None",
    }

    return render(request, "dashboard/dashboard.html", context)
