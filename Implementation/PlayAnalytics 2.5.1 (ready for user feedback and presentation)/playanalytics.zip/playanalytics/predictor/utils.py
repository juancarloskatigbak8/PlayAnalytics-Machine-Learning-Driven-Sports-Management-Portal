from player_profiles.models import PlayerProfile
from collections import Counter

def get_most_common_risk_label():
    risks = PlayerProfile.objects.values_list('predicted_risk_label', flat=True)
    risk_counter = Counter(risks)
    if risk_counter:
        return risk_counter.most_common(1)[0][0]
    return None

