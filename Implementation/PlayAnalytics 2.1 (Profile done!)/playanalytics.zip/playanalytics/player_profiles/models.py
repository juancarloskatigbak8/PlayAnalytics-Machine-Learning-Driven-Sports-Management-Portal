from django.db import models

class PlayerProfile(models.Model):
    name = models.CharField(max_length=100)
    age = models.IntegerField()
    height_in_inches = models.FloatField()
    weight_in_pounds = models.FloatField()
    position = models.CharField(max_length=50)
    games_played = models.IntegerField()
    minutes_played = models.FloatField()
    field_goals_attempted = models.IntegerField()
    threes_attempted = models.IntegerField()
    free_throws_attempted = models.IntegerField()
    steals = models.IntegerField()
    blocks = models.IntegerField()
    fouls = models.IntegerField()
    predicted_risk_label = models.CharField(max_length=50, blank=True, null=True)
    total_injuries = models.IntegerField(default=0)
    most_common_injury = models.CharField(max_length=100, blank=True, null=True)
    profile_picture = models.ImageField(
        upload_to='profile_pictures/',
        blank=True,
        null=True
    )

    def __str__(self):
        return self.name


class PlayerNotes(models.Model):
    player = models.ForeignKey(PlayerProfile, on_delete=models.CASCADE, related_name='notes')
    text = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Note for {self.player.name} on {self.created_at.strftime('%Y-%m-%d')}"
