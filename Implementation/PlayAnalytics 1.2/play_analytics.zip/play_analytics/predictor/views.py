from django.shortcuts import render, redirect
from .forms import PlayerPredictionForm
from profiles.models import Player  # assuming the Player model is in profiles

def predict_injury(request):
    if request.method == 'POST':
        form = PlayerPredictionForm(request.POST)
        if form.is_valid():
            data = form.cleaned_data

            # Save to Player model (to update dashboard/profile later)
            Player.objects.create(
                name=data['player_name'],
                position=data['position'],
                height=data['height'],
                weight=data['weight'],
                age=data['age'],
                avg_minutes=data['avg_minutes'],
                avg_field_goals=data['avg_field_goals'],
                steals=data['steals_per_game'],
                blocks=data['blocks_per_game'],
                fouls=data['fouls_per_game'],
                total_injuries=data['total_injuries'],
                most_common_injury=data['most_common_injury'],
                # Add any other necessary fields
            )

            # You can also add prediction logic here before saving

            return redirect('dashboard')  # or render a result page

    else:
        form = PlayerPredictionForm()

    return render(request, 'predictor/predict.html', {'form': form})
