from django.shortcuts import render, redirect
from .forms import PlayerPredictionForm
from profiles.models import Player
from django.db.models import Count
from django.contrib.auth.decorators import login_required
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from io import BytesIO
import base64
import joblib
import numpy as np
import os
from collections import Counter

model_path = os.path.join(os.path.dirname(__file__), 'rf_injury_model.joblib')
model = joblib.load(model_path)

RISK_LABELS = ['Low', 'Low-Medium', 'Medium', 'Medium-High', 'High']
RISK_MAP = {0: 'Low', 1: 'Low-Medium', 2: 'Medium', 3: 'Medium-High', 4: 'High'}
REVERSE_RISK_MAP = {v: k for k, v in RISK_MAP.items()}

@login_required
def predict_injury(request):
    if request.method == 'POST':
        form = PlayerPredictionForm(request.POST)
        if form.is_valid():
            cd = form.cleaned_data
            cumulative_load = float(cd['avg_minutes']) * int(cd['games_played'])

            features = np.array([
                float(cd['height']),
                float(cd['weight']),
                float(cd['age']),
                float(cd['avg_minutes']),
                float(cd['avg_field_goals']),
                float(cd['steals_per_game']),
                float(cd['blocks_per_game']),
                float(cd['fouls_per_game']),
                float(cd['total_injuries']),
                cumulative_load
            ]).reshape(1, -1)

            prediction = model.predict(features)[0]
            predicted_label = RISK_MAP[prediction]

            # Get most common risk level from saved players
            players = Player.objects.all()
            common_index = (
                players.values('risk_level')
                .annotate(count=Count('risk_level'))
                .order_by('-count')
                .first()
            )
            most_common_label = RISK_MAP[common_index['risk_level']] if common_index else None
            most_common_index = common_index['risk_level'] if common_index else None

            # Chart bars: all zeroes by default
            bar_heights = [0] * len(RISK_LABELS)
            bar_heights[prediction] = 1  # predicted bar has height 1

            fig, ax = plt.subplots()
            bars = ax.bar(RISK_LABELS, bar_heights, color='lightgray')

            # Style predicted bar (solid blue)
            bars[prediction].set_color('cornflowerblue')
            bars[prediction].set_edgecolor('black')
            bars[prediction].set_linewidth(2)

            # Style most common risk bar (dashed outline)
            if most_common_index is not None and most_common_index != prediction:
                bars[most_common_index].set_facecolor('white')
                bars[most_common_index].set_edgecolor('black')
                bars[most_common_index].set_linestyle('--')
                bars[most_common_index].set_linewidth(2)

            ax.set_ylabel("Average Injury Risk (Normalized)")
            ax.set_title("Prediction for Basketball Player Injury Risk")
            ax.set_ylim(0, 1.1)

            img = BytesIO()
            plt.savefig(img, format='png', bbox_inches='tight')
            plt.close()
            img.seek(0)
            chart_url = base64.b64encode(img.getvalue()).decode()

            context = {
                'form': form,
                'prediction': predicted_label,
                'prediction_index': prediction,  # save this for profile
                'most_common': most_common_label,
                'chart': chart_url,
                'submitted_data': cd,
            }
            return render(request, 'predictor/prediction_result.html', context)
    else:
        form = PlayerPredictionForm()

    return render(request, 'predictor/prediction_form.html', {'form': form})

@login_required
def add_to_profile(request):
    if request.method == 'POST':
        user = request.user
        data = request.POST

        avg_minutes = float(data.get('avg_minutes'))
        games_played = int(data.get('games_played'))
        cumulative_load = avg_minutes * games_played

        # Convert back to integer risk index
        risk_label = data.get('risk_level')
        risk_index = REVERSE_RISK_MAP.get(risk_label)

        Player.objects.create(
            user=user,
            player_name=data.get('player_name'),
            position=data.get('position'),
            height=data.get('height'),
            weight=data.get('weight'),
            age=data.get('age'),
            avg_minutes=avg_minutes,
            avg_field_goals=data.get('avg_field_goals'),
            steals_per_game=data.get('steals_per_game'),
            blocks_per_game=data.get('blocks_per_game'),
            fouls_per_game=data.get('fouls_per_game'),
            total_injuries=data.get('total_injuries'),
            most_common_injury=data.get('most_common_injury'),
            risk_level=risk_index,
            cumulative_load=cumulative_load,
            games_played=games_played
        )

    return redirect('profiles:profile')
