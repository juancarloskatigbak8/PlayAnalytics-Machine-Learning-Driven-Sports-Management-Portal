from django import forms
from .models import PlayerProfile, PlayerNotes

class PlayerProfileForm(forms.ModelForm):
    class Meta:
        model = PlayerProfile
        fields = [
            'name', 'age', 'height_in_inches', 'weight_in_pounds', 'position', 'games_played', 'minutes_played',
            'field_goals_attempted', 'three_point_field_goals_attempted', 'free_throws_attempted', 'steals',
            'blocks', 'fouls', 'predicted_risk_label', 'total_injuries', 'most_common_injury',
            'profile_picture'
        ]
        widgets = {
            'position': forms.Select(choices=PlayerProfile.POSITION_CHOICES),
            'most_common_injury': forms.Select(choices=PlayerProfile.INJURY_CHOICES),
            'profile_picture': forms.FileInput(attrs={
                'class': 'form-control',
            })
        }

    def __init__(self, *args, **kwargs):
        super(PlayerProfileForm, self).__init__(*args, **kwargs)
        self.fields['profile_picture'].label = "Change picture"

class PlayerNoteForm(forms.ModelForm):
    class Meta:
        model = PlayerNotes
        fields = ['text']

class NoteForm(forms.ModelForm):
    class Meta:
        model = PlayerNotes
        fields = ['text']

