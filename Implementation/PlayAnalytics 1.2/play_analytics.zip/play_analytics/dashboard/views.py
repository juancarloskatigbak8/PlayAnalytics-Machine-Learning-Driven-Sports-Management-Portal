from django.shortcuts import render
from django.db.models import Avg
from profiles.models import Player
from collections import Counter
import json

def dashboard_view(request):
    players = Player.objects.all()

    total_players = players.count()
    avg_age = round(players.aggregate(avg_age=Avg('age'))['avg_age'] or 0, 1)
    avg_injuries = round(players.aggregate(avg_injuries=Avg('total_injuries'))['avg_injuries'] or 0, 1)

    # Bar Chart: Injuries by Position
    position_injuries = {}
    for player in players:
        pos = player.position
        position_injuries.setdefault(pos, []).append(player.total_injuries)

    bar_labels = list(position_injuries.keys())
    bar_values = [round(sum(vals)/len(vals), 1) if vals else 0 for vals in position_injuries.values()]

    # Pie Chart: Injury Type Distribution
    all_injuries = [player.injury_type for player in players if hasattr(player, 'injury_type') and player.injury_type]
    injury_type_counts = dict(Counter(all_injuries))

    pie_labels = list(injury_type_counts.keys())
    pie_values = list(injury_type_counts.values())

    context = {
        'total_players': total_players,
        'avg_age': avg_age,
        'avg_injuries': avg_injuries,
        'bar_labels': json.dumps(bar_labels),
        'bar_values': json.dumps(bar_values),
        'pie_labels': json.dumps(pie_labels),
        'pie_values': json.dumps(pie_values),
    }

    return render(request, 'dashboard/dashboard.html', context)
