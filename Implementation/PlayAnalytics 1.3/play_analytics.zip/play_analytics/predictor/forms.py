from django import forms

class PlayerPredictionForm(forms.Form):
    player_name = forms.CharField(label="Player Name", max_length=100)
    position = forms.ChoiceField(choices=[('Guard', 'Guard'), ('Forward', 'Forward'), ('Center', 'Center')])
    height = forms.FloatField(label="Height (inches)")
    weight = forms.FloatField(label="Weight (pounds)")
    age = forms.IntegerField(label="Age")
    avg_minutes = forms.FloatField(label="Average Minutes Per Game")
    games_played = forms.IntegerField(label="Games Played")  # 👈 NEW FIELD
    avg_field_goals = forms.FloatField(label="Field Goals Attempted")
    steals_per_game = forms.FloatField(label="Steals Per Game")
    blocks_per_game = forms.FloatField(label="Blocks Per Game")
    fouls_per_game = forms.FloatField(label="Fouls Per Game")
    total_injuries = forms.IntegerField(label="Total Injuries")
    most_common_injury = forms.CharField(label="Most Common Injury", max_length=100)

