from django import forms

INJURY_CHOICES = [
    ('Ankle', 'Ankle'),
    ('Knee', 'Knee'),
    ('Back', 'Back'),
    ('Quad', 'Quad'),
    ('Hamstring', 'Hamstring'),
]

POSITION_CHOICES = [
    ('Guard', 'Guard'),
    ('Forward', 'Forward'),
    ('Center', 'Center'),
]

class PlayerPredictionForm(forms.Form):
    player_name = forms.CharField(label='Player Name', max_length=100)
    position = forms.ChoiceField(choices=POSITION_CHOICES)
    height = forms.IntegerField(label='Height In Inches')
    weight = forms.IntegerField(label='Weight In Pounds')
    age = forms.IntegerField()
    avg_minutes = forms.FloatField(label='Average Minutes Per Game')
    avg_field_goals = forms.FloatField(label='Average Field Goals Attempted')
    steals_per_game = forms.FloatField()
    blocks_per_game = forms.FloatField()
    fouls_per_game = forms.FloatField()
    total_injuries = forms.IntegerField()
    most_common_injury = forms.ChoiceField(choices=INJURY_CHOICES)
