from django.db import models

class PlayerProfile(models.Model):
    POSITION_CHOICES = [
        ('Guard', 'Guard'),
        ('Forward', 'Forward'),
        ('Center', 'Center'),
    ]

    INJURY_CHOICES = [
        ('None', 'None'), ('Ankle', 'Ankle'),('Pectoral', 'Pectoral'), ('Toe', 'Toe'),
        ('Back', 'Back'), ('Knee', 'Knee'), ('Finger', 'Finger'),
        ('Hamstring', 'Hamstring'), ('Groin', 'Groin'), ('Nose', 'Nose'),
        ('Wrist', 'Wrist'), ('Illnesses', 'Illnesses'), ('Thoracic', 'Thoracic'),
        ('Abdominal', 'Abdominal'), ('Adductor', 'Adductor'), ('Foot', 'Foot'),
        ('Calf', 'Calf'), ('Shoulder', 'Shoulder'), ('Hip', 'Hip'),
        ('Concussions', 'Concussions'), ('Neck', 'Neck'), ('Mouth', 'Mouth'),
        ('Quadriceps', 'Quadriceps'), ('Elbow', 'Elbow'), ('Achilles', 'Achilles'),
        ('Oblique', 'Oblique'), ('Eye', 'Eye')
    ]

    name = models.CharField(max_length=100)
    age = models.IntegerField()
    height_in_inches = models.FloatField()
    weight_in_pounds = models.FloatField()
    position = models.CharField(max_length=50, choices=POSITION_CHOICES)
    games_played = models.IntegerField()
    minutes_played = models.FloatField()
    field_goals_attempted = models.IntegerField()
    three_point_field_goals_attempted = models.IntegerField()
    free_throws_attempted = models.IntegerField()
    steals = models.IntegerField()
    blocks = models.IntegerField()
    fouls = models.IntegerField()
    predicted_risk_label = models.CharField(max_length=50, blank=True, null=True)
    total_injuries = models.IntegerField(default=0)
    most_common_injury = models.CharField(max_length=100, choices=INJURY_CHOICES, blank=True, null=True)
    profile_picture = models.ImageField(
        upload_to='profile_pictures/',
        blank=True,
        null=True
    )

    def __str__(self):
        return self.name


class PlayerNotes(models.Model):
    player = models.ForeignKey(PlayerProfile, on_delete=models.CASCADE, related_name='notes')
    text = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Note for {self.player.name} on {self.created_at.strftime('%Y-%m-%d')}"
